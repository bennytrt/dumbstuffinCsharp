﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace KeySystem
{
    class Program
    {
        static void Main(string[] args)
        {
            // A list to store valid keys, u can change the keys, i did not test the limit!
            List<string> validKeys = new List<string>()
            {
                "ABC123",
                "DEF456",
                "GHI789",
                "TEST"
            };

            Console.WriteLine("Enter a key: ");
            string enteredKey = Console.ReadLine();

            // Check if the entered key is in the list of valid keys, like i've said above, u can change the keys and add new one's i didnt test the limit!
            if (validKeys.Contains(enteredKey))
            {
                Console.WriteLine("Key accepted.");

                // will redirect the user when 24 hours has passed, if u want u can change all of the keys in the list above!!
                Task.Delay(TimeSpan.FromHours(24)).ContinueWith((t) =>
                {
                    Process.Start("https://www.example.com"); //make a linkvertise, workink, or raw pastebin link and put it here!
                });
            }
            else
            {
                Console.WriteLine("Invalid key.");
            }

            Console.WriteLine("Press ENTER to exit.");
            Console.ReadLine();
        }
    }
}






// if u got any questions add me on discord! PRXJEK#4242